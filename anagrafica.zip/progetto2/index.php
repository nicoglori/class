<?php

#richiedo la classe
require_once("classe.php");


#carico l'xml
$xml = simplexml_load_file("base.xml");

#print_r($xml);

$db = array();
$label = array();
$holder = array();
$value = array();
$tipo = array();
$fisso = array();
$visibile = array();



$i=0;
$j=0;
foreach ($xml as $key ){
	foreach($key as $chiave=>$valore){
		#echo $i. " INDICE";
		switch($chiave){
			case 'name':
			#ricavo i valori dei campi 
			$db[$i] = strval($valore);
			break;
			
			case 'label':
			$label[$i] = strval($valore);
			break;
			
			case 'placeholder':
			$holder[$i] = strval($valore);
			break;
			
			case 'value':
			$value[$i] = strval($valore);
			break;
			
			case 'tipo':
			$tipo[$i] = strval($valore);
			break;
			
			case 'fisso':
			$fisso[$i] = strval($valore);
			break;
			
			case 'visibile':
			$visibile[$i] = strval($valore);
			break;
		}
		$j++;
		if($j==7){
			$i++;
			$j=0;
		}
		
	}//end foreach
}//end foreach

/*
print_r($db);
print_r($label);
print_r($holder);
print_r($value);
print_r($tipo);
print_r($fisso);
print_r($visibile);
*/


//metodi di classe anagrafica

#1 dire i campi del db
#2 label del dato
#3 placeholder
#4 valore
#5 tipo di dato
#6 campo fisso o aggiuntivo
#7 visibile o no


#ora creo l'oggetto anagrafica
$html = "
<html>
<head>
<title>Form</title>
<link href='style.css' rel='stylesheet'>
</head>
<body>
<div class='login-page'>
  <div class='form'>
<form action='' method='post'>";

for($i=0;$i<count($db);$i++){
	$a[$i] = new Anagrafica($db[$i],$label[$i],$holder[$i],$value[$i],$tipo[$i],$fisso[$i],$visibile[$i]);
	#echo $a->toString();

	
	$html .= $a[$i]->createHTML();

}

$html .= "<input type='submit'></form></div></div></body></html>";
echo $html;

?>