<?php

class Anagrafica{
	
	var $db,$label,$holder,$value,$tipo,$fisso,$visibile;
	
	
	//costruct 
	function __construct($db,$label,$holder,$value,$tipo,$fisso,$visibile){
		$this->db = $db;
		$this->label = $label;
		$this->holder = $holder;
		$this->value = $value;
		$this->tipo = $tipo;
		$this->fisso = $fisso;
		$this->visibile = $visibile;
	}
	
	function insertDB(){
		
	}
	
	//create the HTML
	function createHTML(){
		$html = "";
		if($this->visibile){
			$html = $this->label."<br>";
			switch($this->tipo){
				case 'text':
					if(isset($this->holder))
						$html.= "<input type='text' placeholder='".$this->holder."' value='".$this->value."'><br>";
					else $html.= "<input type='text'><br>";
				break;
				
				case 'select':
				
				break;
				
				case 'data': $html .= "<input type='date' placeholder='".$this->holder."' value='".$this->value."'><br>";
				
				break;
				
				case 'check': $html .= "<input type='checkbox'><br>";
				
				break;
			}
		}
		return $html;
		
	}
	
	//toString of attributes;
	function toString(){
		return $this->db."". 
		$this->label."".
		$this->holder."".
		$this->value."".
		$this->tipo."". 
		$this->fisso."".
		$this->visibile.""; 
	}
}



?>